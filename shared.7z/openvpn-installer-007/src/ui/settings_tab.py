# src/ui/settings_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QDialog
from services.privilege import is_admin

class SettingsWindow(QDialog):
    def __init__(self, priv_message, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Privilege Status")
        layout = QVBoxLayout()
        layout.addWidget(QLabel(priv_message))
        self.setLayout(layout)

class SettingsTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.check_admin_btn = QPushButton("Check Admin/Root Privileges")
        self.check_admin_btn.clicked.connect(self.open_priv_window)
        layout.addWidget(self.check_admin_btn)
        self.setLayout(layout)

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback

    def open_priv_window(self):
        priv_message = "You are running as administrator/root." if is_admin() else "You are NOT running as administrator/root. Some actions may fail."
        win = SettingsWindow(priv_message, self)
        win.exec()
        if hasattr(self, 'log_callback') and self.log_callback:
            self.log_callback(f"Privilege check: {priv_message}")
