# src/services/arg_mapper.py

def map_ui_to_script_args(ui_data):
    """
    Convert UI form data to openvpn-install.sh script arguments.
    ui_data: dict of form values
    Returns: list of command-line arguments
    """
    args = []
    # Example mapping (expand as needed)
    if ui_data.get("port"):
        args += ["--port", str(ui_data["port"])]
    if ui_data.get("protocol"):
        args += ["--protocol", ui_data["protocol"]]
    if ui_data.get("dns_provider"):
        args += ["--dns", ui_data["dns_provider"]]
    # ...add all other mappings as needed...
    return args
