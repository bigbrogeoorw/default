# src/services/openvpn_script.py
import subprocess
import sys
import os
import threading

SCRIPT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../openvpn-install.sh'))

def run_script(command, args=None):
    if args is None:
        args = []
    cmd = ["bash", SCRIPT_PATH, command] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return "", str(e), 1

def run_script_realtime(command, args=None, on_line=None):
    if args is None:
        args = []
    cmd = ["bash", SCRIPT_PATH, command] + args
    output_lines = []
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, universal_newlines=True)
        for line in process.stdout:
            output_lines.append(line)
            if on_line:
                on_line(line.rstrip())
        process.wait()
        returncode = process.returncode
        return "".join(output_lines), "", returncode
    except Exception as e:
        if on_line:
            on_line(str(e))
        return "", str(e), 1
