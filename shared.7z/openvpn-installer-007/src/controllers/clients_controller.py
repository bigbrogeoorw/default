# src/controllers/clients_controller.py
from services.openvpn_script import run_script
from services.output_parser import parse_script_output

class ClientsController:
    def add_client(self, name, password=None, cert_days=None, output_path=None):
        args = ["add", name]
        if password:
            args += ["--password", password]
        if cert_days:
            args += ["--cert-days", str(cert_days)]
        if output_path:
            args += ["--output", output_path]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)

    def revoke_client(self, name, force=False):
        args = ["revoke", name]
        if force:
            args += ["--force"]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)

    def renew_client(self, name, cert_days=None):
        args = ["renew", name]
        if cert_days:
            args += ["--cert-days", str(cert_days)]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)

    def list_clients(self):
        args = ["list", "--format", "json"]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)
