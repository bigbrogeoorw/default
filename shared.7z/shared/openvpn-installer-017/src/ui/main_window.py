# src/ui/main_window.py

import shutil
from PySide6.QtWidgets import QMainWindow, QTabWidget, QTextEdit, QVBoxLayout, QWidget
from PySide6.QtCore import Qt, QThread, Signal
from .install_tab import InstallTab
from .clients_tab import ClientsTab
from .server_tab import ServerTab
from services.openvpn_script import run_script

class WorkerThread(QThread):
    result_signal = Signal(object)
    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs
    def run(self):
        result = self.func(*self.args, **self.kwargs)
        self.result_signal.emit(result)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OpenVPN Installer")
        self.tabs = QTabWidget()
        self.install_tab = InstallTab()
        self.clients_tab = ClientsTab()
        self.server_tab = ServerTab()
        self.tabs.addTab(self.install_tab, "Install")
        self.tabs.addTab(self.clients_tab, "Clients")
        self.tabs.addTab(self.server_tab, "Server")

        # Log output area at the bottom
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMinimumHeight(120)
        self.log_output.setStyleSheet("background: #222; color: #eee; font-family: monospace;")

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        layout.addWidget(self.log_output)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        # Pass log callback to tabs
        self.install_tab.set_log_callback(self.log_event)
        self.clients_tab.set_log_callback(self.log_event)
        self.server_tab.set_log_callback(self.log_event)

        self.check_openvpn()
        self.setMinimumSize(800, 600)
        self.setSizePolicy(QWidget.sizePolicy(self))
        self.setWindowFlag(Qt.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowMinimizeButtonHint, True)
        self.setWindowFlag(Qt.WindowCloseButtonHint, True)
        self.setWindowState(Qt.WindowActive)

    def check_openvpn(self):
        import os
        conf_path = os.path.join(os.path.sep, "etc", "openvpn", "server", "server.conf")
        openvpn_installed = os.path.exists(conf_path)
        self.install_tab.install_btn.setEnabled(not openvpn_installed)
        self.clients_tab.setEnabled(openvpn_installed)
        self.server_tab.renew_btn.setEnabled(openvpn_installed)
        self.install_tab.uninstall_btn.setEnabled(openvpn_installed)
        if openvpn_installed:
            self.log_event(f"OpenVPN found ({conf_path} exists). All features enabled except install.")
        else:
            self.log_event("OpenVPN not found (no server.conf). Only installation is enabled.")

    def log_event(self, message):
        # Only log after event ends, not in real time
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.log_output.append(f"[{timestamp}] {message}")
