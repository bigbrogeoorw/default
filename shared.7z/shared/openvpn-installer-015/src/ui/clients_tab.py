# src/ui/clients_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QMessageBox, QFormLayout, QSpinBox, QFileDialog, QHBoxLayout, QDialog, QTableWidget, QTableWidgetItem, QHeaderView, QProgressBar
from PySide6.QtCore import Qt, Signal

from controllers.clients_controller import ClientsController
from .worker import WorkerThread
from services.openvpn_script import run_script_realtime

class AddClientWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Add Client")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        form = QFormLayout()
        self.name_input = QLineEdit()
        form.addRow("Client Name:", self.name_input)
        self.password_input = QLineEdit()
        form.addRow("Password:", self.password_input)
        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        form.addRow("Cert Validity (days):", self.cert_days_input)
        layout.addLayout(form)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        self.add_btn = QPushButton("Add")
        self.add_btn.clicked.connect(self.add_client)
        layout.addWidget(self.add_btn)
        self.setLayout(layout)
        self.setModal(True)

    def add_client(self):
        self.add_btn.setEnabled(False)
        self.progress.setVisible(True)
        name = self.name_input.text().strip()
        password = self.password_input.text().strip()
        cert_days = self.cert_days_input.value()
        def do_add():
            args = [name]
            if password:
                args += ["--password", password]
            if cert_days:
                args += ["--cert-days", str(cert_days)]
            stdout, stderr, returncode = run_script_realtime("client", ["add"] + args, on_line=None)
            return {"success": returncode == 0, "message": "Client added" if returncode == 0 else stderr or stdout}
        self.thread = WorkerThread(do_add)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client added"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        self.progress.setVisible(False)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)
        self.add_btn.setEnabled(True)
        self.parent().refresh_clients()

class RevokeClientWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Revoke Client")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        self.name_input = QLineEdit()
        layout.addWidget(QLabel("Client Name:"))
        layout.addWidget(self.name_input)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        self.revoke_btn = QPushButton("Revoke")
        self.revoke_btn.clicked.connect(self.revoke_client)
        layout.addWidget(self.revoke_btn)
        self.setLayout(layout)
        self.setModal(True)

    def revoke_client(self):
        self.revoke_btn.setEnabled(False)
        self.progress.setVisible(True)
        name = self.name_input.text().strip()
        def do_revoke():
            args = [name]
            stdout, stderr, returncode = run_script_realtime("client", ["revoke"] + args, on_line=None)
            return {"success": returncode == 0, "message": "Client revoked" if returncode == 0 else stderr or stdout}
        self.thread = WorkerThread(do_revoke)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client revoked"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        self.progress.setVisible(False)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)
        self.revoke_btn.setEnabled(True)
        self.parent().refresh_clients()

class RenewClientWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Renew Certificate")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        self.name_input = QLineEdit()
        layout.addWidget(QLabel("Client Name:"))
        layout.addWidget(self.name_input)
        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        layout.addWidget(QLabel("Cert Validity (days):"))
        layout.addWidget(self.cert_days_input)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        self.renew_btn = QPushButton("Renew")
        self.renew_btn.clicked.connect(self.renew_client)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)
        self.setModal(True)

    def renew_client(self):
        self.renew_btn.setEnabled(False)
        self.progress.setVisible(True)
        name = self.name_input.text().strip()
        cert_days = self.cert_days_input.value()
        def do_renew():
            args = [name]
            if cert_days:
                args += ["--cert-days", str(cert_days)]
            stdout, stderr, returncode = run_script_realtime("client", ["renew"] + args, on_line=None)
            return {"success": returncode == 0, "message": "Client renewed" if returncode == 0 else stderr or stdout}
        self.thread = WorkerThread(do_renew)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client renewed"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        self.progress.setVisible(False)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)
        self.renew_btn.setEnabled(True)
        self.parent().refresh_clients()

class ClientActionButtons(QWidget):
    revoke_clicked = Signal(str)
    renew_clicked = Signal(str)
    def __init__(self, client_name):
        super().__init__()
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        self.revoke_btn = QPushButton("Revoke")
        self.revoke_btn.setObjectName("revokeBtn")
        self.renew_btn = QPushButton("Renew")
        self.renew_btn.setObjectName("renewBtn")
        self.revoke_btn.clicked.connect(lambda: self.revoke_clicked.emit(client_name))
        self.renew_btn.clicked.connect(lambda: self.renew_clicked.emit(client_name))
        layout.addWidget(self.revoke_btn)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)

class ClientsTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ClientsController()
        main_layout = QVBoxLayout()
        # Header
        header_layout = QHBoxLayout()
        header_label = QLabel("<b>OpenVPN Clients</b>")
        header_label.setStyleSheet("font-size: 18px;")
        header_layout.addWidget(header_label, alignment=Qt.AlignLeft)
        self.add_btn = QPushButton("Add Client")
        self.add_btn.setObjectName("addBtn")
        header_layout.addWidget(self.add_btn, alignment=Qt.AlignRight)
        main_layout.addLayout(header_layout)
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Client Name", "Status", "Expiry", "Remaining", "Actions"])
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        main_layout.addWidget(self.table)
        self.setLayout(main_layout)
        self.add_btn.clicked.connect(self.open_add_client_window)
        self.client_data = []
        self.setStyleSheet(self.table_qss())
        self.refresh_clients()

    def refresh_clients(self):
        def do_list():
            result = self.controller.list_clients()
            import json
            clients = []
            if result["success"]:
                try:
                    data = result["message"]
                    # Try to extract the 'clients' key if present (for {"clients": [...]})
                    if data.strip().startswith("{"):
                        obj = json.loads(data)
                        if isinstance(obj, dict) and "clients" in obj:
                            clients = obj["clients"]
                        else:
                            clients = obj if isinstance(obj, list) else []
                    elif data.strip().startswith("["):
                        clients = json.loads(data)
                    else:
                        clients = [{"name": line.strip()} for line in data.splitlines() if line.strip()]
                except Exception:
                    clients = [{"name": line.strip()} for line in result["message"].splitlines() if line.strip()]
            return clients
        self.thread = WorkerThread(do_list)
        self.thread.result_signal.connect(self.populate_table)
        self.thread.start()

    def table_qss(self):
        return """
        QTableWidget {
            border: none;
            background: #f8f9fa;
        }
        QTableWidget::item:selected {
            background: #e3f2fd;
        }
        QTableWidget::item:hover {
            background: #e9ecef;
        }
        QHeaderView::section {
            background: #f1f3f4;
            border: none;
            font-weight: bold;
            padding: 6px;
        }
        QPushButton#revokeBtn {
            background: #e53935;
            color: white;
            border-radius: 4px;
            padding: 4px 12px;
        }
        QPushButton#revokeBtn:hover {
            background: #b71c1c;
        }
        QPushButton#renewBtn, QPushButton#addBtn {
            background: #1976d2;
            color: white;
            border-radius: 4px;
            padding: 4px 12px;
        }
        QPushButton#renewBtn:hover, QPushButton#addBtn:hover {
            background: #1565c0;
        }
        """

    def populate_table(self, client_data):
        self.table.setRowCount(len(client_data))
        self.client_data = client_data
        for row, client in enumerate(client_data):
            self.table.setItem(row, 0, QTableWidgetItem(client.get("name", "")))
            self.table.setItem(row, 1, QTableWidgetItem(client.get("status", "")))
            self.table.setItem(row, 2, QTableWidgetItem(client.get("expiry", "")))
            self.table.setItem(row, 3, QTableWidgetItem(client.get("remaining", "")))
            action_widget = ClientActionButtons(client.get("name", ""))
            action_widget.revoke_clicked.connect(self.revoke_client)
            action_widget.renew_clicked.connect(self.renew_client)
            self.table.setCellWidget(row, 4, action_widget)

    def open_add_client_window(self):
        win = AddClientWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.setModal(True)
        win.exec()
        self.refresh_clients()

    def revoke_client(self, client_name):
        win = RevokeClientWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.setModal(True)
        win.exec()
        self.refresh_clients()

    def handle_revoke_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client revoked"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)
        self.refresh_clients()

    def renew_client(self, client_name):
        win = RenewClientWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.setModal(True)
        win.exec()
        self.refresh_clients()

    def handle_renew_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client renewed"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)
        self.refresh_clients()

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback
