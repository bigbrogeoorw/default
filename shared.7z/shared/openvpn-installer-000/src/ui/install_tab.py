# src/ui/install_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QMessageBox, QFormLayout, QSpinBox, QDialog
from .worker import WorkerThread
from controllers.install_controller import InstallController

class InstallWizardWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Install OpenVPN Wizard")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        form = QFormLayout()
        # GUI fields for OpenVPN install options
        self.port_input = QSpinBox()
        self.port_input.setRange(1, 65535)
        self.port_input.setValue(1194)
        form.addRow("Port:", self.port_input)
        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(["udp", "tcp"])
        form.addRow("Protocol:", self.protocol_combo)
        self.dns_combo = QComboBox()
        self.dns_combo.addItems(["cloudflare", "google", "system", "custom"])
        form.addRow("DNS Provider:", self.dns_combo)
        self.multi_client_checkbox = QCheckBox("Allow multi-client")
        form.addRow(self.multi_client_checkbox)
        layout.addLayout(form)
        self.install_btn = QPushButton("Install")
        self.install_btn.clicked.connect(self.install_openvpn)
        layout.addWidget(self.install_btn)
        self.setLayout(layout)

    def install_openvpn(self):
        ui_data = {
            "port": self.port_input.value(),
            "protocol": self.protocol_combo.currentText(),
            "dns_provider": self.dns_combo.currentText(),
            "multi_client": self.multi_client_checkbox.isChecked(),
        }
        def do_install():
            return self.controller.install(ui_data)
        self.thread = WorkerThread(do_install)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        if self.log_callback:
            self.log_callback(f"Install OpenVPN: {result['message']}")
        QMessageBox.information(self, "Result", result["message"])

class UninstallWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Uninstall OpenVPN")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Are you sure you want to uninstall OpenVPN?"))
        self.uninstall_btn = QPushButton("Uninstall")
        self.uninstall_btn.clicked.connect(self.uninstall_openvpn)
        layout.addWidget(self.uninstall_btn)
        self.setLayout(layout)

    def uninstall_openvpn(self):
        result = self.controller.uninstall()
        if self.log_callback:
            self.log_callback(f"Uninstall OpenVPN: {result['message']}")
        QMessageBox.information(self, "Result", result["message"])

class InstallTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = InstallController()
        layout = QVBoxLayout()
        self.install_btn = QPushButton("Install OpenVPN Server")
        self.install_btn.clicked.connect(self.open_install_wizard)
        layout.addWidget(self.install_btn)
        self.uninstall_btn = QPushButton("Uninstall OpenVPN Server")
        self.uninstall_btn.clicked.connect(self.open_uninstall_window)
        layout.addWidget(self.uninstall_btn)
        self.setLayout(layout)

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback

    def open_install_wizard(self):
        win = InstallWizardWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()

    def open_uninstall_window(self):
        win = UninstallWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()
