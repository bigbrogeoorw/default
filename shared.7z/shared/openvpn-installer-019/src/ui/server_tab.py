# src/ui/server_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QSpinBox, QMessageBox, QFormLayout, QDialog, QProgressBar
from controllers.server_controller import ServerController
from .worker import WorkerThread
from services.openvpn_script import run_script_realtime

class RenewServerCertWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Renew Server Certificate")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        form = QFormLayout()
        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        form.addRow("Cert Validity (days):", self.cert_days_input)
        layout.addLayout(form)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        self.renew_btn = QPushButton("Renew")
        self.renew_btn.clicked.connect(self.renew_cert)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)
        self.setModal(True)

    def renew_cert(self):
        self.renew_btn.setEnabled(False)
        self.progress.setVisible(True)
        cert_days = self.cert_days_input.value()
        def do_renew():
            args = ["--cert-days", str(cert_days)] if cert_days else []
            stdout, stderr, returncode = run_script_realtime("server", ["renew"] + args, on_line=None)
            return {"success": returncode == 0, "message": "Server certificate renewed" if returncode == 0 else stderr or stdout}
        self.thread = WorkerThread(do_renew)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Server certificate renewed"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        self.progress.setVisible(False)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)
        self.renew_btn.setEnabled(True)
        self.parent().refresh_server_tab()

class ServerTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ServerController()
        layout = QVBoxLayout()
        self.renew_btn = QPushButton("Renew Server Certificate")
        self.renew_btn.clicked.connect(self.open_renew_cert_window)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback

    def open_renew_cert_window(self):
        self.renew_cert_dialog = RenewServerCertWindow(self, self.controller, getattr(self, 'log_callback', None))
        self.renew_cert_dialog.setModal(True)
        self.renew_cert_dialog.exec()
        del self.renew_cert_dialog

    def refresh_server_tab(self):
        # Placeholder for refresh logic if needed
        pass
