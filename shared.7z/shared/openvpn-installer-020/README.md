# OpenVPN Installer

## Overview

This project is a Windows-based OpenVPN installer and management tool. It provides a graphical user interface (GUI) for installing, configuring, and managing an OpenVPN server and its clients. The application leverages Python for the backend logic and shell scripts for actual OpenVPN operations.

## Project Structure

```
src/
├── main.py
├── openvpn-install.sh
├── controllers/
│   ├── clients_controller.py
│   ├── install_controller.py
│   ├── server_controller.py
│   └── __pycache__/
├── services/
│   ├── arg_mapper.py
│   ├── openvpn_script.py
│   ├── output_parser.py
│   ├── privilege.py
│   └── __pycache__/
└── ui/
    ├── clients_tab.py
    ├── install_tab.py
    ├── main_window.py
    ├── server_tab.py
    ├── settings_tab.py
    ├── status_tab.py
    ├── worker.py
    └── __pycache__/
```

## Components and Interconnections

### 1. `main.py`

- Entry point for the application.
- Initializes the GUI and orchestrates the main workflow.

### 2. `openvpn-install.sh`

- Bash script for installing and configuring OpenVPN.
- Invoked by backend services to perform system-level operations.

### 3. `controllers/`

- **clients_controller.py**: Handles client management logic (add/remove clients, generate configs).
- **install_controller.py**: Manages installation workflow and interacts with the installer script.
- **server_controller.py**: Controls server configuration and status.

### 4. `services/`

- **arg_mapper.py**: Maps GUI actions to script arguments.
- **openvpn_script.py**: Executes shell scripts and manages their output.
- **output_parser.py**: Parses script output for display in the UI.
- **privilege.py**: Handles privilege escalation and checks for admin rights.

### 5. `ui/`

- **main_window.py**: Main application window; coordinates tabs and user actions.
- **clients_tab.py**: UI for managing OpenVPN clients.
- **install_tab.py**: UI for installation and setup.
- **server_tab.py**: UI for server configuration and status.
- **settings_tab.py**: UI for application settings.
- **status_tab.py**: UI for displaying logs and status messages.
- **worker.py**: Background worker for running tasks without blocking the UI.

## Workflow

1. User launches the application (`main.py`).
2. The GUI (`ui/`) is initialized, presenting various tabs for installation, server, clients, settings, and status.
3. User actions in the UI trigger controller logic (`controllers/`), which in turn call service functions (`services/`).
4. Services may invoke the shell script (`openvpn-install.sh`) for system operations.
5. Output from scripts is parsed and displayed in the UI.

## How Components Interact

- **UI** → **Controllers**: UI elements call controller methods based on user actions.
- **Controllers** → **Services**: Controllers use services to perform business logic and interact with scripts.
- **Services** → **Shell Script**: Services execute the shell script and parse its output.
- **Services** → **UI**: Parsed output and status are sent back to the UI for display.

## Requirements

- Python 3.x
- OpenVPN
- Windows OS

## Usage

1. Run `main.py` to start the application.
2. Use the GUI to install OpenVPN, configure the server, and manage clients.

## License

MIT License

---

For detailed documentation, refer to comments in each module.
