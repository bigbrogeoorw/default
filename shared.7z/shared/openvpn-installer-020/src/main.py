# src/main.py

import sys
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow

def main() -> None:
    """Entry point for the OpenVPN Installer application.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
