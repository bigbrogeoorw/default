# src/controllers/server_controller.py
from services.openvpn_script import run_script
from services.output_parser import parse_script_output

class ServerController:
    """Controller for OpenVPN server operations."""

    def status(self) -> dict:
        """Get the status of the OpenVPN server.

        Args:
            None

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["status", "--format", "json"]
        stdout, stderr, returncode = run_script("server", args)
        return parse_script_output(stdout, stderr, returncode)

    def renew_certificate(self, cert_days: int = None, force: bool = False) -> dict:
        """Renew the OpenVPN server certificate.

        Args:
            cert_days (int, optional): Certificate validity in days. Defaults to None.
            force (bool, optional): Force renewal. Defaults to False.

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["renew"]
        if cert_days:
            args += ["--cert-days", str(cert_days)]
        if force:
            args += ["--force"]
        stdout, stderr, returncode = run_script("server", args)
        return parse_script_output(stdout, stderr, returncode)
