# src/controllers/clients_controller.py
from services.openvpn_script import run_script
from services.output_parser import parse_script_output

class ClientsController:
    """Controller for managing OpenVPN clients."""

    def add_client(self, name: str, password: str = None, cert_days: int = None, output_path: str = None) -> dict:
        """Add a new OpenVPN client.

        Args:
            name (str): Client name.
            password (str, optional): Password for the client. Defaults to None.
            cert_days (int, optional): Certificate validity in days. Defaults to None.
            output_path (str, optional): Path to output client config. Defaults to None.

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["add", name]
        if password:
            args += ["--password", password]
        if cert_days:
            args += ["--cert-days", str(cert_days)]
        if output_path:
            args += ["--output", output_path]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)

    def revoke_client(self, name: str, force: bool = False) -> dict:
        """Revoke an OpenVPN client certificate.

        Args:
            name (str): Client name.
            force (bool, optional): Force revoke. Defaults to False.

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["revoke", name]
        if force:
            args += ["--force"]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)

    def renew_client(self, name: str, cert_days: int = None) -> dict:
        """Renew an OpenVPN client certificate.

        Args:
            name (str): Client name.
            cert_days (int, optional): Certificate validity in days. Defaults to None.

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["renew", name]
        if cert_days:
            args += ["--cert-days", str(cert_days)]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)

    def list_clients(self) -> dict:
        """List all OpenVPN clients.

        Args:
            None

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["list", "--format", "json"]
        stdout, stderr, returncode = run_script("client", args)
        return parse_script_output(stdout, stderr, returncode)
