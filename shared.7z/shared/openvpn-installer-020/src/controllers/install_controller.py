# src/controllers/install_controller.py
from services.openvpn_script import run_script
from services.arg_mapper import map_ui_to_script_args
from services.output_parser import parse_script_output

class InstallController:
    """Controller for OpenVPN installation and uninstallation."""

    def install(self, ui_data: dict) -> dict:
        """Install OpenVPN using UI data.

        Args:
            ui_data (dict): Dictionary of form values from the UI.

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = map_ui_to_script_args(ui_data)
        stdout, stderr, returncode = run_script("install", args)
        return parse_script_output(stdout, stderr, returncode)

    def uninstall(self, force: bool = False) -> dict:
        """Uninstall OpenVPN.

        Args:
            force (bool, optional): Force uninstall. Defaults to False.

        Returns:
            dict: Result dictionary from script output.

        Raises:
            None
        """
        args = ["--force"] if force else []
        stdout, stderr, returncode = run_script("uninstall", args)
        return parse_script_output(stdout, stderr, returncode)

    def uninstall_realtime(self, force: bool = False, on_line: callable = None) -> dict:
        """Uninstall OpenVPN and stream output in real time.

        Args:
            force (bool, optional): Force uninstall. Defaults to False.
            on_line (callable, optional): Callback for each output line. Defaults to None.

        Returns:
            dict: Dictionary with success, stdout, stderr, and returncode.

        Raises:
            None
        """
        args = ["--force"] if force else []
        from services.openvpn_script import run_script_realtime
        stdout, stderr, returncode = run_script_realtime("uninstall", args, on_line=on_line)
        # Return dict similar to parse_script_output
        return {"success": returncode == 0, "stdout": stdout, "stderr": stderr, "returncode": returncode}
