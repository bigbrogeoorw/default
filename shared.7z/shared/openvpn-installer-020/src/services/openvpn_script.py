# src/services/openvpn_script.py
import subprocess
import sys
import os
import threading

# PyInstaller: get script path from bundle or source
if hasattr(sys, '_MEIPASS'):
    SCRIPT_PATH = os.path.join(sys._MEIPASS, 'openvpn-install.sh')
else:
    SCRIPT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../openvpn-install.sh'))

def run_script(command: str, args: list[str] = None) -> tuple[str, str, int]:
    """Run the openvpn-install.sh script with the given command and arguments.

    Args:
        command (str): The command to execute (e.g., 'install', 'client').
        args (list[str], optional): List of additional arguments. Defaults to None.

    Returns:
        tuple[str, str, int]: stdout, stderr, and return code from the script.

    Raises:
        Exception: If subprocess fails to run.
    """
    if args is None:
        args = []
    cmd = ["bash", SCRIPT_PATH, command] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return "", str(e), 1

def run_script_realtime(command: str, args: list[str] = None, on_line: callable = None) -> tuple[str, str, int]:
    """Run the openvpn-install.sh script and stream output lines in real time.

    Args:
        command (str): The command to execute.
        args (list[str], optional): List of additional arguments. Defaults to None.
        on_line (callable, optional): Callback for each output line. Defaults to None.

    Returns:
        tuple[str, str, int]: Combined stdout, stderr, and return code.

    Raises:
        Exception: If subprocess fails to run.
    """
    if args is None:
        args = []
    cmd = ["bash", SCRIPT_PATH, command] + args
    output_lines = []
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, universal_newlines=True)
        for line in process.stdout:
            output_lines.append(line)
            if on_line:
                on_line(line.rstrip())
        process.wait()
        returncode = process.returncode
        return "".join(output_lines), "", returncode
    except Exception as e:
        if on_line:
            on_line(str(e))
        return "", str(e), 1
