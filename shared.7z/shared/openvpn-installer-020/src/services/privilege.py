# src/services/privilege.py
import os
import sys

def is_admin() -> bool:
    """Check if the current user has administrative privileges.

    Args:
        None

    Returns:
        bool: True if the user is admin/root, False otherwise.

    Raises:
        Exception: If privilege check fails (Windows only).
    """
    if sys.platform == 'win32':
        import ctypes
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except Exception:
            return False
    else:
        return os.geteuid() == 0
