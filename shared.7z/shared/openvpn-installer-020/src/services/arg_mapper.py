# src/services/arg_mapper.py

def map_ui_to_script_args(ui_data: dict) -> list:
    """Convert UI form data to openvpn-install.sh script arguments.

    Args:
        ui_data (dict): Dictionary of form values from the UI.

    Returns:
        list: List of command-line arguments for the script.

    Raises:
        None
    """
    args = []
    # Example mapping (expand as needed)
    if ui_data.get("port"):
        args += ["--port", str(ui_data["port"])]
    if ui_data.get("protocol"):
        args += ["--protocol", ui_data["protocol"]]
    if ui_data.get("dns_provider"):
        args += ["--dns", ui_data["dns_provider"]]
    # ...add all other mappings as needed...
    return args
