# src/services/output_parser.py
def parse_script_output(stdout: str, stderr: str, returncode: int) -> dict:
    """Parse the output from the openvpn-install.sh script and return a result dict.

    Args:
        stdout (str): Standard output from the script.
        stderr (str): Standard error from the script.
        returncode (int): Return code from the script.

    Returns:
        dict: Dictionary with 'success' (bool) and 'message' (str).

    Raises:
        None
    """
    if returncode == 0:
        return {"success": True, "message": stdout.strip()}
    else:
        return {"success": False, "message": stderr.strip() or stdout.strip()}
