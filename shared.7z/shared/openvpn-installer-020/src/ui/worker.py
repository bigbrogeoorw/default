from PySide6.QtCore import QThread, Signal

class WorkerThread(QThread):
    """Thread for running background tasks and emitting results."""
    result_signal = Signal(object)

    def __init__(self, func: callable, *args, **kwargs) -> None:
        """Initialize the worker thread.

        Args:
            func (callable): Function to run in the thread.
            *args: Arguments for the function.
            **kwargs: Keyword arguments for the function.

        Returns:
            None

        Raises:
            None
        """
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def run(self) -> None:
        """Execute the function and emit the result."""
        result = self.func(*self.args, **self.kwargs)
        self.result_signal.emit(result)
