# src/ui/clients_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QMessageBox, QFormLayout, QSpinBox, QFileDialog, QHBoxLayout, QDialog

from controllers.clients_controller import ClientsController
from .worker import WorkerThread

class AddClientWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Add Client")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        form = QFormLayout()
        self.name_input = QLineEdit()
        form.addRow("Client Name:", self.name_input)
        self.password_input = QLineEdit()
        form.addRow("Password:", self.password_input)
        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        form.addRow("Cert Validity (days):", self.cert_days_input)
        layout.addLayout(form)
        self.add_btn = QPushButton("Add")
        self.add_btn.clicked.connect(self.add_client)
        layout.addWidget(self.add_btn)
        self.setLayout(layout)

    def add_client(self):
        name = self.name_input.text().strip()
        password = self.password_input.text().strip()
        cert_days = self.cert_days_input.value()
        def do_add():
            return self.controller.add_client(name, password, cert_days)
        self.thread = WorkerThread(do_add)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client added"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)

class RevokeClientWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Revoke Client")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        self.name_input = QLineEdit()
        layout.addWidget(QLabel("Client Name:"))
        layout.addWidget(self.name_input)
        self.revoke_btn = QPushButton("Revoke")
        self.revoke_btn.clicked.connect(self.revoke_client)
        layout.addWidget(self.revoke_btn)
        self.setLayout(layout)

    def revoke_client(self):
        name = self.name_input.text().strip()
        def do_revoke():
            return self.controller.revoke_client(name)
        self.thread = WorkerThread(do_revoke)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client revoked"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)

class RenewClientWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Renew Certificate")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        self.name_input = QLineEdit()
        layout.addWidget(QLabel("Client Name:"))
        layout.addWidget(self.name_input)
        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        layout.addWidget(QLabel("Cert Validity (days):"))
        layout.addWidget(self.cert_days_input)
        self.renew_btn = QPushButton("Renew")
        self.renew_btn.clicked.connect(self.renew_client)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)

    def renew_client(self):
        name = self.name_input.text().strip()
        cert_days = self.cert_days_input.value()
        def do_renew():
            return self.controller.renew_client(name, cert_days)
        self.thread = WorkerThread(do_renew)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Client renewed"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)

class ClientsTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ClientsController()
        layout = QVBoxLayout()
        self.list_btn = QPushButton("Show Active Clients")
        self.list_btn.clicked.connect(self.show_clients)
        layout.addWidget(self.list_btn)
        self.add_btn = QPushButton("Add Client")
        self.add_btn.clicked.connect(self.open_add_client_window)
        layout.addWidget(self.add_btn)
        self.revoke_btn = QPushButton("Revoke Client")
        self.revoke_btn.clicked.connect(self.open_revoke_client_window)
        layout.addWidget(self.revoke_btn)
        self.renew_btn = QPushButton("Renew Certificate")
        self.renew_btn.clicked.connect(self.open_renew_client_window)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback

    def open_add_client_window(self):
        win = AddClientWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()

    def open_revoke_client_window(self):
        win = RevokeClientWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()

    def open_renew_client_window(self):
        win = RenewClientWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()

    def show_clients(self):
        result = self.controller.list_clients()
        dlg = QDialog(self)
        dlg.setWindowTitle("Active Clients")
        layout = QVBoxLayout()
        layout.addWidget(QLabel(result["message"]))
        dlg.setLayout(layout)
        dlg.exec()
        if hasattr(self, 'log_callback') and self.log_callback:
            self.log_callback(f"List clients: {result['message']}")
