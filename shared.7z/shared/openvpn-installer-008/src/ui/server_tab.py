# src/ui/server_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QSpinBox, QMessageBox, QFormLayout, QDialog
from controllers.server_controller import ServerController
from .worker import WorkerThread
from services.openvpn_script import run_script_realtime

class RenewServerCertWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Renew Server Certificate")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        form = QFormLayout()
        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        form.addRow("Cert Validity (days):", self.cert_days_input)
        layout.addLayout(form)
        self.renew_btn = QPushButton("Renew")
        self.renew_btn.clicked.connect(self.renew_cert)
        layout.addWidget(self.renew_btn)
        self.setLayout(layout)

    def renew_cert(self):
        cert_days = self.cert_days_input.value()
        def do_renew():
            lines = []
            def on_line(line):
                lines.append(line)
                if self.log_callback:
                    self.log_callback(line)
            args = ["--cert-days", str(cert_days)] if cert_days else []
            stdout, stderr, returncode = run_script_realtime("server", ["renew"] + args, on_line=on_line)
            return {"success": returncode == 0, "message": "Server certificate renewed" if returncode == 0 else stderr or stdout}
        self.thread = WorkerThread(do_renew)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Server certificate renewed"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)

class ServerStatusWindow(QDialog):
    def __init__(self, status_message, parent=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Server Status")
        layout = QVBoxLayout()
        layout.addWidget(QLabel(status_message))
        self.setLayout(layout)
        if log_callback:
            log_callback(f"Show server status: {status_message}")

class ServerTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ServerController()
        layout = QVBoxLayout()
        self.renew_btn = QPushButton("Renew Server Certificate")
        self.renew_btn.clicked.connect(self.open_renew_cert_window)
        layout.addWidget(self.renew_btn)
        self.status_btn = QPushButton("Show Server Status")
        self.status_btn.clicked.connect(self.open_status_window)
        layout.addWidget(self.status_btn)
        self.setLayout(layout)

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback

    def open_renew_cert_window(self):
        win = RenewServerCertWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()

    def open_status_window(self):
        def do_status():
            return self.controller.status()
        self.thread = WorkerThread(do_status)
        self.thread.result_signal.connect(self.handle_status_result)
        self.thread.start()

    def handle_status_result(self, result):
        win = ServerStatusWindow(result["message"], self, getattr(self, 'log_callback', None))
        win.exec()
