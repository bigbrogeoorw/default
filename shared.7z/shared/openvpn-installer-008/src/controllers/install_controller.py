# src/controllers/install_controller.py
from services.openvpn_script import run_script
from services.arg_mapper import map_ui_to_script_args
from services.output_parser import parse_script_output

class InstallController:
    def install(self, ui_data):
        args = map_ui_to_script_args(ui_data)
        stdout, stderr, returncode = run_script("install", args)
        return parse_script_output(stdout, stderr, returncode)

    def uninstall(self, force=False):
        args = ["--force"] if force else []
        stdout, stderr, returncode = run_script("uninstall", args)
        return parse_script_output(stdout, stderr, returncode)

    def uninstall_realtime(self, force=False, on_line=None):
        args = ["--force"] if force else []
        from services.openvpn_script import run_script_realtime
        stdout, stderr, returncode = run_script_realtime("uninstall", args, on_line=on_line)
        # Return dict similar to parse_script_output
        return {"success": returncode == 0, "stdout": stdout, "stderr": stderr, "returncode": returncode}
