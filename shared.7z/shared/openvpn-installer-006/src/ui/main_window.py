# src/ui/main_window.py

import shutil
from PySide6.QtWidgets import QMainWindow, QTabWidget, QTextEdit, QVBoxLayout, QWidget
from PySide6.QtCore import Qt, QThread, Signal
from .install_tab import InstallTab
from .clients_tab import ClientsTab
from .server_tab import ServerTab
from .status_tab import StatusTab
from .settings_tab import SettingsTab
from services.openvpn_script import run_script

class WorkerThread(QThread):
    result_signal = Signal(object)
    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs
    def run(self):
        result = self.func(*self.args, **self.kwargs)
        self.result_signal.emit(result)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OpenVPN Installer")
        self.tabs = QTabWidget()
        self.install_tab = InstallTab()
        self.clients_tab = ClientsTab()
        self.server_tab = ServerTab()
        self.status_tab = StatusTab()
        self.settings_tab = SettingsTab()
        self.tabs.addTab(self.install_tab, "Install")
        self.tabs.addTab(self.clients_tab, "Clients")
        self.tabs.addTab(self.server_tab, "Server")
        self.tabs.addTab(self.status_tab, "Status")
        self.tabs.addTab(self.settings_tab, "Settings")

        # Log output area at the bottom
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMinimumHeight(120)
        self.log_output.setStyleSheet("background: #222; color: #eee; font-family: monospace;")

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        layout.addWidget(self.log_output)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        # Pass log callback to tabs
        self.install_tab.set_log_callback(self.log_event)
        self.clients_tab.set_log_callback(self.log_event)
        self.server_tab.set_log_callback(self.log_event)
        self.settings_tab.set_log_callback(self.log_event)

        self.check_openvpn()

    def check_openvpn(self):
        # Use angristan's logic: check for /etc/openvpn/server/server.conf
        import os
        conf_path = "/etc/openvpn/server/server.conf"
        if not os.path.exists(conf_path):
            self.clients_tab.setEnabled(False)
            self.server_tab.status_btn.setEnabled(False)
            self.install_tab.uninstall_btn.setEnabled(False)
            self.log_event("OpenVPN not found (no server.conf). Only installation is enabled.")
        else:
            self.clients_tab.setEnabled(True)
            self.server_tab.status_btn.setEnabled(True)
            self.install_tab.uninstall_btn.setEnabled(True)
            self.log_event(f"OpenVPN found ({conf_path} exists). All features enabled.")

    def log_event(self, message):
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.log_output.append(f"[{timestamp}] {message}")
