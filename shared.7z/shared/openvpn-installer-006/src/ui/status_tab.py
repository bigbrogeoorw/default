# src/ui/status_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QMessageBox, QDialog
from controllers.server_controller import ServerController

class StatusWindow(QDialog):
    def __init__(self, status_message, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Server Status")
        layout = QVBoxLayout()
        layout.addWidget(QLabel(status_message))
        self.setLayout(layout)

class StatusTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ServerController()
        layout = QVBoxLayout()
        self.status_btn = QPushButton("Refresh Server Status")
        self.status_btn.clicked.connect(self.open_status_window)
        layout.addWidget(self.status_btn)
        self.setLayout(layout)

    def open_status_window(self):
        result = self.controller.status()
        win = StatusWindow(result["message"], self)
        win.exec()
