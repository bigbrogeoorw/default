# src/ui/install_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QMessageBox, QFormLayout, QSpinBox, QDialog
from .worker import WorkerThread
from controllers.install_controller import InstallController
from services.openvpn_script import run_script_realtime

class InstallWizardWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Install OpenVPN Wizard")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        form = QFormLayout()
        # IP version for clients
        self.ip_version_combo = QComboBox()
        self.ip_version_combo.addItems(["IPv4", "IPv6", "Both"])
        form.addRow("Client IP version:", self.ip_version_combo)
        # Server listening IPv4 address
        self.listen_ip_input = QLineEdit()
        form.addRow("Server listening IPv4 address:", self.listen_ip_input)
        # Public IPv4/hostname (NAT)
        self.public_ip_input = QLineEdit()
        form.addRow("Public IPv4/hostname:", self.public_ip_input)
        # VPN client IP versions
        self.vpn_ip_version_combo = QComboBox()
        self.vpn_ip_version_combo.addItems(["IPv4", "IPv6", "Both"])
        form.addRow("VPN client IP version:", self.vpn_ip_version_combo)
        # IPv4 VPN subnet
        self.vpn_subnet_input = QLineEdit()
        form.addRow("IPv4 VPN subnet:", self.vpn_subnet_input)
        # Port
        self.port_input = QSpinBox()
        self.port_input.setRange(1, 65535)
        self.port_input.setValue(1194)
        form.addRow("Port:", self.port_input)
        # Protocol
        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(["udp", "tcp"])
        form.addRow("Protocol:", self.protocol_combo)
        # Multi-client
        self.multi_client_checkbox = QCheckBox("Allow multi-client profile")
        form.addRow(self.multi_client_checkbox)
        # Tunnel MTU
        self.mtu_mode_combo = QComboBox()
        self.mtu_mode_combo.addItems(["Default (1500)", "Custom"])
        form.addRow("Tunnel MTU mode:", self.mtu_mode_combo)
        self.mtu_custom_input = QSpinBox()
        self.mtu_custom_input.setRange(576, 9000)
        self.mtu_custom_input.setValue(1500)
        self.mtu_custom_input.setEnabled(False)
        form.addRow("Custom MTU:", self.mtu_custom_input)
        self.mtu_mode_combo.currentIndexChanged.connect(lambda idx: self.mtu_custom_input.setEnabled(idx == 1))
        # Authentication mode
        self.auth_mode_combo = QComboBox()
        self.auth_mode_combo.addItems(["PKI (Certificate Authority)", "Peer Fingerprint"])
        form.addRow("Authentication mode:", self.auth_mode_combo)
        # Encryption settings
        self.custom_encrypt_checkbox = QCheckBox("Customize encryption settings")
        form.addRow(self.custom_encrypt_checkbox)
        layout.addLayout(form)
        self.install_btn = QPushButton("Install")
        self.install_btn.clicked.connect(self.install_openvpn)
        layout.addWidget(self.install_btn)
        self.setLayout(layout)

    def install_openvpn(self):
        ui_data = {
            "ip_version": self.ip_version_combo.currentText(),
            "listen_ip": self.listen_ip_input.text().strip(),
            "public_ip": self.public_ip_input.text().strip(),
            "vpn_ip_version": self.vpn_ip_version_combo.currentText(),
            "vpn_subnet": self.vpn_subnet_input.text().strip(),
            "port": self.port_input.value(),
            "protocol": self.protocol_combo.currentText(),
            "multi_client": self.multi_client_checkbox.isChecked(),
            "mtu_mode": self.mtu_mode_combo.currentText(),
            "custom_mtu": self.mtu_custom_input.value() if self.mtu_mode_combo.currentIndex() == 1 else None,
            "auth_mode": self.auth_mode_combo.currentText(),
            "custom_encrypt": self.custom_encrypt_checkbox.isChecked(),
        }
        def do_install():
            lines = []
            def on_line(line):
                lines.append(line)
                if self.log_callback:
                    self.log_callback(line)
            from controllers.install_controller import map_ui_to_script_args
            args = map_ui_to_script_args(ui_data)
            stdout, stderr, returncode = run_script_realtime("install", args, on_line=on_line)
            return {"success": returncode == 0, "message": "Server installed" if returncode == 0 else stderr or stdout}
        self.thread = WorkerThread(do_install)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Server installed"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)

class UninstallWindow(QDialog):
    def __init__(self, parent=None, controller=None, log_callback=None):
        super().__init__(parent)
        self.setWindowTitle("Uninstall OpenVPN")
        self.controller = controller
        self.log_callback = log_callback
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Are you sure you want to uninstall OpenVPN?"))
        self.uninstall_btn = QPushButton("Uninstall")
        self.uninstall_btn.clicked.connect(self.uninstall_openvpn)
        layout.addWidget(self.uninstall_btn)
        self.setLayout(layout)

    def uninstall_openvpn(self):
        def do_uninstall():
            return self.controller.uninstall()
        self.thread = WorkerThread(do_uninstall)
        self.thread.result_signal.connect(self.handle_result)
        self.thread.start()

    def handle_result(self, result):
        msg = result["message"]
        if result["success"]:
            short_msg = "Server uninstalled"
        else:
            short_msg = f"Failed: {msg}"
        if self.log_callback:
            self.log_callback(short_msg)
        QMessageBox.information(self, "Result", short_msg) if result["success"] else QMessageBox.critical(self, "Error", short_msg)

class InstallTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = InstallController()
        layout = QVBoxLayout()
        self.install_btn = QPushButton("Install OpenVPN Server")
        self.install_btn.clicked.connect(self.open_install_wizard)
        layout.addWidget(self.install_btn)
        self.uninstall_btn = QPushButton("Uninstall OpenVPN Server")
        self.uninstall_btn.clicked.connect(self.open_uninstall_window)
        layout.addWidget(self.uninstall_btn)
        self.setLayout(layout)

    def set_log_callback(self, log_callback):
        self.log_callback = log_callback

    def open_install_wizard(self):
        win = InstallWizardWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()

    def open_uninstall_window(self):
        win = UninstallWindow(self, self.controller, getattr(self, 'log_callback', None))
        win.exec()
