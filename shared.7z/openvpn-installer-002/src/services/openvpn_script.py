# src/services/openvpn_script.py
import subprocess
import sys
import os

SCRIPT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../openvpn-install.sh'))


def run_script(command, args=None):
    if args is None:
        args = []
    cmd = ["bash", SCRIPT_PATH, command] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return "", str(e), 1
