# src/ui/main_window.py

from PySide6.QtWidgets import QMainWindow, QTabWidget
from .install_tab import InstallTab
from .clients_tab import ClientsTab
from .server_tab import ServerTab
from .status_tab import StatusTab
from .settings_tab import SettingsTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OpenVPN Installer")
        self.tabs = QTabWidget()
        self.tabs.addTab(InstallTab(), "Install")
        self.tabs.addTab(ClientsTab(), "Clients")
        self.tabs.addTab(ServerTab(), "Server")
        self.tabs.addTab(StatusTab(), "Status")
        self.tabs.addTab(SettingsTab(), "Settings")
        self.setCentralWidget(self.tabs)
