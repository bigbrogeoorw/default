# src/ui/server_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QSpinBox, QMessageBox, QFormLayout
from controllers.server_controller import ServerController

class ServerTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ServerController()
        layout = QVBoxLayout()
        form = QFormLayout()

        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        form.addRow("Renew Cert Validity (days):", self.cert_days_input)
        layout.addLayout(form)

        self.renew_btn = QPushButton("Renew Server Certificate")
        self.renew_btn.clicked.connect(self.renew_cert)
        layout.addWidget(self.renew_btn)

        self.status_btn = QPushButton("Show Server Status")
        self.status_btn.clicked.connect(self.show_status)
        layout.addWidget(self.status_btn)

        self.setLayout(layout)

    def renew_cert(self):
        cert_days = self.cert_days_input.value()
        result = self.controller.renew_certificate(cert_days)
        self.show_result(result)

    def show_status(self):
        result = self.controller.status()
        if result["success"]:
            QMessageBox.information(self, "Server Status", result["message"])
        else:
            QMessageBox.critical(self, "Error", result["message"])

    def show_result(self, result):
        if result["success"]:
            QMessageBox.information(self, "Success", result["message"])
        else:
            QMessageBox.critical(self, "Error", result["message"])
