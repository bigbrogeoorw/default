# src/ui/install_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QMessageBox, QFormLayout, QSpinBox
from controllers.install_controller import InstallController

class InstallTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = InstallController()
        layout = QVBoxLayout()
        form = QFormLayout()

        # Example controls (expand as needed)
        self.port_input = QSpinBox()
        self.port_input.setRange(1, 65535)
        self.port_input.setValue(1194)
        form.addRow("Port:", self.port_input)

        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(["udp", "tcp"])
        form.addRow("Protocol:", self.protocol_combo)

        self.dns_combo = QComboBox()
        self.dns_combo.addItems(["cloudflare", "google", "system", "custom"])
        form.addRow("DNS Provider:", self.dns_combo)

        self.multi_client_checkbox = QCheckBox("Allow multi-client")
        form.addRow(self.multi_client_checkbox)

        layout.addLayout(form)

        self.install_btn = QPushButton("Install OpenVPN Server")
        self.install_btn.clicked.connect(self.install_action)
        layout.addWidget(self.install_btn)

        self.uninstall_btn = QPushButton("Uninstall OpenVPN Server")
        self.uninstall_btn.clicked.connect(self.uninstall_action)
        layout.addWidget(self.uninstall_btn)

        self.setLayout(layout)

    def install_action(self):
        ui_data = {
            "port": self.port_input.value(),
            "protocol": self.protocol_combo.currentText(),
            "dns_provider": self.dns_combo.currentText(),
            "multi_client": self.multi_client_checkbox.isChecked(),
        }
        result = self.controller.install(ui_data)
        self.show_result(result)

    def uninstall_action(self):
        result = self.controller.uninstall()
        self.show_result(result)

    def show_result(self, result):
        if result["success"]:
            QMessageBox.information(self, "Success", result["message"])
        else:
            QMessageBox.critical(self, "Error", result["message"])
