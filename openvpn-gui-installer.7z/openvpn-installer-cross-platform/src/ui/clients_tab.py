# src/ui/clients_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QCheckBox, QMessageBox, QFormLayout, QSpinBox, QFileDialog, QHBoxLayout
from controllers.clients_controller import ClientsController

class ClientsTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ClientsController()
        layout = QVBoxLayout()
        form = QFormLayout()

        self.name_input = QLineEdit()
        form.addRow("Client Name:", self.name_input)

        self.password_checkbox = QCheckBox("Password Protect")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setEnabled(False)
        self.password_checkbox.stateChanged.connect(lambda: self.password_input.setEnabled(self.password_checkbox.isChecked()))
        form.addRow(self.password_checkbox, self.password_input)

        self.cert_days_input = QSpinBox()
        self.cert_days_input.setRange(1, 36500)
        self.cert_days_input.setValue(3650)
        form.addRow("Cert Validity (days):", self.cert_days_input)

        self.output_path_input = QLineEdit()
        self.browse_btn = QPushButton("Browse")
        self.browse_btn.clicked.connect(self.browse_output)
        output_layout = QHBoxLayout()
        output_layout.addWidget(self.output_path_input)
        output_layout.addWidget(self.browse_btn)
        form.addRow("Output Path:", output_layout)

        layout.addLayout(form)

        self.add_btn = QPushButton("Add Client")
        self.add_btn.clicked.connect(self.add_client)
        layout.addWidget(self.add_btn)

        self.revoke_name_input = QLineEdit()
        self.revoke_btn = QPushButton("Revoke Client")
        self.revoke_btn.clicked.connect(self.revoke_client)
        revoke_layout = QHBoxLayout()
        revoke_layout.addWidget(self.revoke_name_input)
        revoke_layout.addWidget(self.revoke_btn)
        layout.addLayout(revoke_layout)

        self.renew_name_input = QLineEdit()
        self.renew_btn = QPushButton("Renew Client Certificate")
        self.renew_btn.clicked.connect(self.renew_client)
        renew_layout = QHBoxLayout()
        renew_layout.addWidget(self.renew_name_input)
        renew_layout.addWidget(self.renew_btn)
        layout.addLayout(renew_layout)

        self.list_btn = QPushButton("List Clients")
        self.list_btn.clicked.connect(self.list_clients)
        layout.addWidget(self.list_btn)

        self.setLayout(layout)

    def browse_output(self):
        path, _ = QFileDialog.getSaveFileName(self, "Select Output File", "", "*.ovpn")
        if path:
            self.output_path_input.setText(path)

    def add_client(self):
        name = self.name_input.text().strip()
        password = self.password_input.text() if self.password_checkbox.isChecked() else None
        cert_days = self.cert_days_input.value()
        output_path = self.output_path_input.text().strip() or None
        if not name:
            QMessageBox.warning(self, "Input Error", "Client name is required.")
            return
        result = self.controller.add_client(name, password, cert_days, output_path)
        self.show_result(result)

    def revoke_client(self):
        name = self.revoke_name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Input Error", "Client name is required to revoke.")
            return
        result = self.controller.revoke_client(name)
        self.show_result(result)

    def renew_client(self):
        name = self.renew_name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Input Error", "Client name is required to renew.")
            return
        result = self.controller.renew_client(name)
        self.show_result(result)

    def list_clients(self):
        result = self.controller.list_clients()
        if result["success"]:
            QMessageBox.information(self, "Clients", result["message"])
        else:
            QMessageBox.critical(self, "Error", result["message"])

    def show_result(self, result):
        if result["success"]:
            QMessageBox.information(self, "Success", result["message"])
        else:
            QMessageBox.critical(self, "Error", result["message"])
