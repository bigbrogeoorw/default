# src/services/output_parser.py
def parse_script_output(stdout, stderr, returncode):
    if returncode == 0:
        return {"success": True, "message": stdout.strip()}
    else:
        return {"success": False, "message": stderr.strip() or stdout.strip()}
