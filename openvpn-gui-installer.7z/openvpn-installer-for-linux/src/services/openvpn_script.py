# src/services/openvpn_script.py
import subprocess
import sys
import os

SCRIPT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../openvpn-install.sh'))


def run_script(command, args=None):
    if sys.platform.startswith('win'):
        from PySide6.QtWidgets import QApplication, QMessageBox
        import ctypes
        # Ensure a QApplication exists for the message box
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        QMessageBox.critical(None, "Unsupported Platform", (
            "OpenVPN installation and management require a Linux environment or WSL.\n"
            "Please run this app on a Linux machine or enable WSL with bash support."))
        # Ensure the message box is shown before exit
        app.processEvents()
        sys.exit(1)
    if args is None:
        args = []
    cmd = ["bash", SCRIPT_PATH, command] + args
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return "", str(e), 1
