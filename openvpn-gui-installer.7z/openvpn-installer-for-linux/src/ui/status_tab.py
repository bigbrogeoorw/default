# src/ui/status_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QMessageBox
from controllers.server_controller import ServerController

class StatusTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ServerController()
        layout = QVBoxLayout()
        self.status_btn = QPushButton("Refresh Server Status")
        self.status_btn.clicked.connect(self.show_status)
        layout.addWidget(self.status_btn)
        self.status_label = QLabel("")
        layout.addWidget(self.status_label)
        self.setLayout(layout)
        self.show_status()

    def show_status(self):
        result = self.controller.status()
        if result["success"]:
            self.status_label.setText(result["message"])
        else:
            QMessageBox.critical(self, "Error", result["message"])
            self.status_label.setText("")

    def setEnabled(self, enabled: bool):
        for child in self.findChildren(QWidget):
            child.setEnabled(enabled)
