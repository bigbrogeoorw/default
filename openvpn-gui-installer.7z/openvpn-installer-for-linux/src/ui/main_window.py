# src/ui/main_window.py

from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QPushButton, QStackedWidget, QSizePolicy
from PySide6.QtCore import Qt
from .install_tab import InstallTab
from .clients_tab import ClientsTab
from .server_tab import ServerTab
from .status_tab import StatusTab
from .settings_tab import SettingsTab
from services.openvpn_script import run_script

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OpenVPN Installer")
        self.setMinimumSize(900, 600)
        self.setStyleSheet("QMainWindow { background: #16213a; }")

        # Sidebar
        sidebar = QVBoxLayout()
        sidebar.setContentsMargins(0, 0, 0, 0)
        sidebar.setSpacing(12)
        self.btns = []
        self.sections = ["Install", "Clients", "Server", "Status", "Settings"]
        for i, name in enumerate(self.sections):
            btn = QPushButton(name)
            btn.setCheckable(True)
            btn.setMinimumHeight(48)
            btn.setStyleSheet(self._sidebar_btn_qss())
            btn.clicked.connect(lambda checked, idx=i: self.switch_tab(idx))
            sidebar.addWidget(btn)
            self.btns.append(btn)
        sidebar.addStretch(1)
        sidebar_widget = QWidget()
        sidebar_widget.setLayout(sidebar)
        sidebar_widget.setFixedWidth(180)
        sidebar_widget.setStyleSheet("background: #202b40;")

        # Main content area
        self.stack = QStackedWidget()
        self.install_tab = InstallTab()
        self.clients_tab = ClientsTab()
        self.server_tab = ServerTab()
        self.status_tab = StatusTab()
        self.settings_tab = SettingsTab()
        self.stack.addWidget(self.install_tab)
        self.stack.addWidget(self.clients_tab)
        self.stack.addWidget(self.server_tab)
        self.stack.addWidget(self.status_tab)
        self.stack.addWidget(self.settings_tab)

        # Layout
        main_layout = QHBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(sidebar_widget)
        main_layout.addWidget(self.stack)
        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

        # Initial state
        self.switch_tab(0)
        self.update_server_state()

    def switch_tab(self, idx):
        for i, btn in enumerate(self.btns):
            btn.setChecked(i == idx)
        self.stack.setCurrentIndex(idx)
        # Optionally update state on tab switch
        if idx in (0, 1):
            self.update_server_state()

    def update_server_state(self):
        installed = self.is_server_installed()
        # Disable install button if already installed, enable otherwise
        if hasattr(self.install_tab, 'install_btn'):
            self.install_tab.install_btn.setEnabled(not installed)
        # Disable all client management if not installed
        if hasattr(self.clients_tab, 'setEnabled'):
            self.clients_tab.setEnabled(installed)
        # Optionally disable server/status actions if not installed
        if hasattr(self.server_tab, 'setEnabled'):
            self.server_tab.setEnabled(installed)
        if hasattr(self.status_tab, 'setEnabled'):
            self.status_tab.setEnabled(installed)

    def is_server_installed(self):
        # Use the backend to check if OpenVPN is installed
        stdout, stderr, returncode = run_script("server", ["status"])
        # If status returns success, assume installed
        return returncode == 0

    def _sidebar_btn_qss(self):
        return (
            "QPushButton { background: #16213a; color: #fff; border: none; border-radius: 8px; font-size: 18px; font-weight: bold; }"
            "QPushButton:checked { background: #ff7a2f; color: #fff; }"
            "QPushButton:hover { background: #ff944d; }"
        )
