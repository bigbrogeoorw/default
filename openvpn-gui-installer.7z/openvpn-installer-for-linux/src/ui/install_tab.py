# src/ui/install_tab.py
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit, QHBoxLayout, QButtonGroup, QRadioButton, QFrame, QStackedWidget, QProgressBar, QGroupBox)
from PySide6.QtCore import Qt
from controllers.install_controller import InstallController

class InstallTab(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = InstallController()
        self.setStyleSheet(self._modern_qss())
        main_layout = QVBoxLayout(self)

        # Card-style form
        card = QGroupBox("Server Settings")
        card.setStyleSheet("QGroupBox { background: #202b40; border: 2px solid #ff7a2f; border-radius: 16px; margin-top: 16px; color: #fff; font-size: 18px; font-weight: bold; padding: 16px; } QGroupBox:title { subcontrol-origin: margin; left: 16px; top: -12px; background: #202b40; padding: 0 8px; }")
        card_layout = QVBoxLayout(card)

        # Public IP (disabled)
        self.ip_input = QLineEdit("auto-detected IP")
        self.ip_input.setEnabled(False)
        card_layout.addWidget(self._form_row("Public IPv4 Address:", self.ip_input))

        # Protocol pill buttons
        proto_row = QHBoxLayout()
        self.udp_btn = QPushButton("UDP")
        self.tcp_btn = QPushButton("TCP")
        for btn in (self.udp_btn, self.tcp_btn):
            btn.setCheckable(True)
            btn.setMinimumHeight(36)
            btn.setStyleSheet("QPushButton { border-radius: 8px; font-size: 16px; padding: 8px 32px; background: #1a2233; color: #fff; border: 2px solid #1a2233; } QPushButton:checked { background: #ff7a2f; color: #fff; border: 2px solid #ff7a2f; }")
        self.udp_btn.setChecked(True)
        self.udp_btn.clicked.connect(lambda: self.tcp_btn.setChecked(False))
        self.tcp_btn.clicked.connect(lambda: self.udp_btn.setChecked(False))
        proto_row.addWidget(self.udp_btn)
        proto_row.addWidget(self.tcp_btn)
        card_layout.addWidget(self._form_row("Protocol:", proto_row))

        # Port
        self.port_input = QLineEdit("1194")
        self.port_input.setStyleSheet("QLineEdit { border-radius: 8px; padding: 8px; font-size: 16px; background: #1a2233; color: #fff; border: 1px solid #3a4a6a; }")
        card_layout.addWidget(self._form_row("Port:", self.port_input))

        # DNS pill buttons
        dns_row = QHBoxLayout()
        self.dns_buttons = []
        for label in ["Current system resolvers", "See others", "Google", "Cloudflare", "Etc..."]:
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setMinimumHeight(36)
            btn.setStyleSheet("QPushButton { border-radius: 8px; font-size: 16px; padding: 8px 16px; background: #1a2233; color: #fff; border: 2px solid #1a2233; } QPushButton:checked { background: #ff7a2f; color: #fff; border: 2px solid #ff7a2f; }")
            btn.clicked.connect(lambda checked, b=btn: self._dns_selected(b))
            self.dns_buttons.append(btn)
            dns_row.addWidget(btn)
        self.dns_buttons[0].setChecked(True)
        card_layout.addWidget(self._form_row("DNS Server:", dns_row))

        # Install button is now disabled if server is installed
        self.install_btn = QPushButton("Install")
        self.install_btn.setEnabled(True)  # Will be updated by MainWindow
        self.install_btn.setMinimumHeight(40)
        self.install_btn.setStyleSheet("QPushButton { background: #ff7a2f; color: #fff; border-radius: 8px; font-size: 18px; font-weight: bold; padding: 8px 32px; } QPushButton:hover { background: #ff944d; }")
        card_layout.addWidget(self.install_btn, alignment=Qt.AlignRight)

        # Next button
        self.next_btn = QPushButton("Next")
        self.next_btn.setMinimumHeight(40)
        self.next_btn.setStyleSheet("QPushButton { background: #ff7a2f; color: #fff; border-radius: 8px; font-size: 18px; font-weight: bold; padding: 8px 32px; } QPushButton:hover { background: #ff944d; }")
        self.next_btn.clicked.connect(self._on_next)
        card_layout.addWidget(self.next_btn, alignment=Qt.AlignRight)

        main_layout.addWidget(card, alignment=Qt.AlignLeft)
        main_layout.addStretch(1)

    def _form_row(self, label, widget):
        row_widget = QWidget()
        row_layout = QHBoxLayout(row_widget)
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.addWidget(QLabel(label))
        if isinstance(widget, QHBoxLayout):
            container = QWidget()
            container.setLayout(widget)
            row_layout.addWidget(container)
        else:
            row_layout.addWidget(widget)
        return row_widget

    def _dns_selected(self, btn):
        for b in self.dns_buttons:
            b.setChecked(b is btn)

    def _on_next(self):
        # Placeholder for next step logic
        pass

    def _modern_qss(self):
        return """
        QWidget { background: #16213a; color: #fff; font-family: 'Segoe UI', 'Arial', sans-serif; }
        QLabel { font-size: 16px; }
        """
