# src/ui/settings_tab.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QMessageBox
from services.privilege import is_admin

class SettingsTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Settings"))

        self.check_admin_btn = QPushButton("Check Admin/Root Privileges")
        self.check_admin_btn.clicked.connect(self.check_admin)
        layout.addWidget(self.check_admin_btn)

        self.priv_label = QLabel("")
        layout.addWidget(self.priv_label)

        self.setLayout(layout)
        self.check_admin()

    def check_admin(self):
        if is_admin():
            self.priv_label.setText("You are running as administrator/root.")
        else:
            self.priv_label.setText("You are NOT running as administrator/root. Some actions may fail.")
