# src/controllers/server_controller.py
from services.openvpn_script import run_script
from services.output_parser import parse_script_output

class ServerController:
    def status(self):
        args = ["status", "--format", "json"]
        stdout, stderr, returncode = run_script("server", args)
        return parse_script_output(stdout, stderr, returncode)

    def renew_certificate(self, cert_days=None, force=False):
        args = ["renew"]
        if cert_days:
            args += ["--cert-days", str(cert_days)]
        if force:
            args += ["--force"]
        stdout, stderr, returncode = run_script("server", args)
        return parse_script_output(stdout, stderr, returncode)
