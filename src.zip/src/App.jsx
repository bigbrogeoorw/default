import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import LoginPage from "./components/LoginPage";
import ProtectedRoute from "./components/ProtectedRoute";
import PublicRoute from "./components/PublicRoute";
import HomePage from "./components/HomePage";
import { ConfigProvider } from "antd";

function App() {
  return (
    <ConfigProvider
      theme={{
        components: {
          Layout: {
            headerBg: "inherit",
            bodyBg: "white",
            siderBg: "white",
            triggerBg: "gray",
          },
          Tooltip: {
            colorBgSpotlight: "rgba(0, 0, 0, 0.45)",
            colorTextLightSolid: "white",
          },
          Menu: {
            subMenuItemBg: "#ffffff",
            itemColor: "rgb(69, 94, 84)",
            itemHoverColor: "rgb(50, 79, 67)",
            itemHoverBg: "rgb(198, 230, 216)",
            itemSelectedColor: "rgb(69, 94, 84)",
            itemSelectedBg: "rgb(214, 244, 231)",
            itemActiveBg: "rgb(183, 239, 215)",
          },
        },
      }}
    >
      <Router>
        <Routes>
          <Route
            path="/login"
            element={
              <PublicRoute>
                <LoginPage />
              </PublicRoute>
            }
          />

          <Route
            path="/home"
            element={
              <ProtectedRoute>
                <HomePage />
              </ProtectedRoute>
            }
          />

          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      </Router>
    </ConfigProvider>
  );
}

export default App;
