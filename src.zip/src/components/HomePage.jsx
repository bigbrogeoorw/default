import { Layout, Menu, Button } from "antd";
import {
  UserOutlined,
  VideoCameraOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import UserDropDownMenu from "./UserDropdownMenu";
import styles from "./styles/HomePage.module.css";

const { Sider, Header, Content } = Layout;

const homePage = () => {
  const user = JSON.parse(localStorage.getItem("user"));

  const sidebarItems = [
    {
      key: "sub1",
      label: "Contributions",
      icon: <UserOutlined />,
      children: [
        {
          key: "1",
          icon: <UserOutlined />,
          label: "nav 1",
        },
        {
          key: "2",
          icon: <VideoCameraOutlined />,
          label: "nav 2",
        },
        {
          key: "3",
          icon: <UploadOutlined />,
          label: "nav 3",
        },
      ],
    },
  ];
  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Header
        style={{
          display: "flex",
          justifyContent: "space-between",
          height: "8vh",
          alignItems: "center",
          borderBottom: "1px solid #ececec",
        }}
      >
        <Button type="text" icon={<HomeOutlinedIcon />} />
        <UserDropDownMenu>
          <Button type="text" icon={<UserOutlined />}>
            {`${user.first_name} ${user.last_name}`}
          </Button>
        </UserDropDownMenu>
      </Header>
      <Layout>
        <Sider collapsible>
          <Menu
            mode="inline"
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            items={sidebarItems}
            style={{ minHeight: "100%" }}
          />
        </Sider>
        <Content></Content>
      </Layout>
    </Layout>
  );
};
export default homePage;
