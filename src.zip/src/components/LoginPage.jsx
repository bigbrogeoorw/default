import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import styles from "./styles/loginpage.module.css";

const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(""); // Stores Oracle/Django errors
  const [loading, setLoading] = useState(false); // Disables button during magic

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      // Logic: Send credentials to Django manageaccounts
      const response = await axios.post(
        "http://localhost:8000/api/auth/login/",
        {
          username: username,
          password: password,
        }
      );

      // Magic is true: Store JWT and User Profile
      localStorage.setItem("access_token", response.data.access);
      localStorage.setItem("user", JSON.stringify(response.data.user));

      // Go to home page
      navigate("/home");
    } catch (err) {
      // Magic failed: Show error message
      if (err.response) {
        setError(err.response.data.error || "Invalid username or password");
      } else {
        setError("Server is offline. Check your Django backend.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <main className={styles.main}>
        <div className={styles.card}>
          <div className={styles.header}>
            <h1 className={styles.title}>Welcome back!</h1>
          </div>

          <form onSubmit={handleSubmit} className={styles["form-container"]}>
            {/* Display error message if credentials are wrong */}
            {error && <div className={styles["error-banner"]}>{error}</div>}

            <div className={styles["input-group"]}>
              <label htmlFor="username" className={styles.label}>
                Username
              </label>
              <input
                type="text"
                id="username"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className={styles.input}
              />

              <label htmlFor="password" className={styles.label}>
                Password
              </label>
              <input
                type="password"
                id="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={styles.input}
              />
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className={styles.button}
              >
                {loading ? "Verifying..." : "Log In"}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};

export default LoginPage;
