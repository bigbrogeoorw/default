import { Dropdown, message, Tooltip } from "antd";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import DirectionsRunOutlinedIcon from "@mui/icons-material/DirectionsRunOutlined";
import { useNavigate } from "react-router-dom";

const UserDropDownMenu = ({ children }) => {
  const navigate = useNavigate();

  const handleMenuClick = ({ key }) => {
    if (key === "2") {
      localStorage.removeItem("user");
      localStorage.removeItem("access_token");

      message.success("Logged out successfully");
      navigate("/login");
    }
  };

  const items = [
    {
      key: "1",
      label: (
        <Tooltip title="Go to the settings!" placement="left">
          <span>Settings</span>
        </Tooltip>
      ),
      icon: <SettingsOutlinedIcon />,
    },
    {
      type: "divider",
    },
    {
      key: "2",
      label: (
        <Tooltip title="Sign out now!" placement="bottom">
          <span>Log out</span>
        </Tooltip>
      ),
      icon: <DirectionsRunOutlinedIcon />,
    },
  ];

  return (
    <Dropdown menu={{ items, onClick: handleMenuClick }}>{children}</Dropdown>
  );
};

export default UserDropDownMenu;
