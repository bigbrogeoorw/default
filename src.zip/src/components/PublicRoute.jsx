import React from "react";
import { Navigate } from "react-router-dom";

const PublicRoute = ({ children }) => {
  const user = localStorage.getItem("user");
  const token = localStorage.getItem("access_token");

  if (user && token) {
    return <Navigate to="/home" replace />;
  }

  return children;
};

export default PublicRoute;
